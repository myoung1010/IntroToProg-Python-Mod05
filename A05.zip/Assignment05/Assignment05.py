# ---------------------------------------------------------------------------
# Title: Assignment05.py
# Desc: This assignment demonstrates using dictionaries, files, and exception handling
# Change Log: (Who, When, What)
#   RRoot, 01/01/2030, Created Script
#   Matthew Young, 02/24/2025, Updated script with dictionary data processing and structured error handling capabilities.
# ---------------------------------------------------------------------------

import json

# Define the Data Constants

MENU: str = '''
---- Course Registration Program ----
  Select from the following menu:
      1. Register a Student for a Course
      2. Show current data.
      3. Save data to a file.
      4. Exit the program.
-------------------------------------
'''

FILE_NAME: str = "Enrollments.json"

# Define the Data Variables
student_first_name: str = ''  # Holds the first name of a student entered by the user.
student_last_name: str = ''  # Holds the last name of a student entered by the user.
course_name: str = ''  # Holds the name of a course entered by the user.
student_data: dict = {}  # Dictionary of student data
students: list = []  # Table of student data
file = None  # Holds a reference to an opened file
menu_choice: str  # Holds the choice made by the user.

# When the program starts, read the file data into a table
# Extract the data from the JSON file
try:
    file = open(FILE_NAME, "r")
    data = json.load(file)
    file.close()

except FileNotFoundError as e:
    print("\nJSON file must exist before running this program!\n")
    print("-- Technical Error Message -- ")
    print(e, e.__doc__, type(e), sep='\n')

except Exception as e:
    print("\nThere was a non-specific error!\n")
    print("-- Technical Error Message -- ")
    print(e, e.__doc__, type(e), sep='\n')

finally:
    if file.closed == False:
        file.close()

for student in data:
    try:
        # Check for numbers in student's name in read file data
        if student['FirstName'].isalpha() and student['LastName'].isalpha():
            # Load it into our collection (list of lists)
            students.append(student)
            continue

        else:
            # Display error message
            raise ValueError(
                f"An invalid name '{student['FirstName']} {student['LastName']}' is contained in the file. Name was skipped.")

    except ValueError as e:
        print("\n-- Technical Error Message -- ")
        print(e.__doc__)
        print(e.__str__())

    except Exception as e:
        print("\nThere was a non-specific error!\n")
        print("-- Tehcnical Error Message -- ")
        print(e, e.__doc__, type(e), sep='\n')

# Present and Process the Data
while (True):
    # Present the menu of choices
    print(MENU)
    menu_choice = input("What would you like to do: ")

    # Input user data
    if menu_choice == "1":  # This will not work if it is an integer
        try:
            # Check for numbers in students name
            student_first_name = input("Enter the student's first name: ")
            if not student_first_name.isalpha():
                raise ValueError("The first name should not contain numbers.")
            student_last_name = input("Enter the student's last name: ")
            if not student_last_name.isalpha():
                raise ValueError("The last name should not contain numbers.")
            course_name = input("Please enter the name of the course: ")

            student_data = {'FirstName': student_first_name, 'LastName': student_last_name, 'CourseName': course_name}
            students.append(student_data)
            print(f"You have registered {student_first_name} {student_last_name} for {course_name}.")
            continue

        # Display error message
        except ValueError as e:
            print("\n-- Technical Error Message -- ")
            print(e.__doc__)
            print(e.__str__())
            pass

        except Exception as e:
            print("\nThere was a non-specific error!\n")
            print("-- Tehcnical Error Message -- ")
            print(e, e.__doc__, type(e), sep='\n')
            pass

    elif menu_choice == "2":
        # Process the data to create and display a custom message
        print("-" * 50)
        for student in students:
            print(f"Student {student['FirstName']} {student['LastName']} is enrolled in {student['CourseName']}")
        print("-" * 50)
        continue

    elif menu_choice == "3":
        try:
            # Save data to the JSON file
            file = open(FILE_NAME, "w")
            json.dump(students, file, indent="")
            file.close()

            print("The following data was saved to file!")
            for student in students:
                print(f"Student {student['FirstName']} {student['LastName']} is enrolled in {student['CourseName']}")
            continue

        except TypeError as e:
            print("\nPlease check that that data is a valid JSON format.\n")
            print("-- Tehcnical Error Message -- ")
            print(e, e.__doc__, type(e), sep='\n')
        except Exception as e:
            print("\n-- Technical Error Message -- ")
            print("Built-In Python error info: ")
            print(e, e.__doc__, type(e), sep='\n')

        finally:
            if file.closed == False:
                file.close()

    elif menu_choice == "4":
        break  # out of the loop

    else:
        print("Please only choose option 1, 2, or 3")

print("Program Ended")